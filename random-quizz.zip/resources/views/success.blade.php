@extends('layouts.app')

@section('content')
    <div class="container">

        <h1>Parabens</h1>

        <h2>Você ganhou</h2>

    </div>
@endsection
