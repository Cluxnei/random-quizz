<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1><?php echo e($question->title); ?></h1>
        <small>Categoria(s): <?php echo e($question->commaCategories); ?></small>
        <p><?php echo e($question->description); ?></p>

        <h2>Resposta:</h2>

        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('check.answer', $answer->id)); ?>" class="check-answer"><?php echo e($answer->title); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\random-quizz\resources\views/question.blade.php ENDPATH**/ ?>