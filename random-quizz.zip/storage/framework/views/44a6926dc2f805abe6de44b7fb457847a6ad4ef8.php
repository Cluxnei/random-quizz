<?php $__env->startSection('content'); ?>

    <h1>Ranking</h1>
    
    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th >Nick</th>
                <th>Score</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $counter = 1;
            ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($counter++); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->score); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </tbody>
      </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\random-quizz\resources\views/ranking.blade.php ENDPATH**/ ?>