<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Parabens</h1>

        <h2>Você ganhou</h2>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\random-quizz\resources\views/success.blade.php ENDPATH**/ ?>