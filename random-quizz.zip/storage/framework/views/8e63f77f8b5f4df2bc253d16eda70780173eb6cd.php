<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Home</h1>

        <form id="random-question" action="<?php echo e(route('random.question')); ?>">
            <input type="text" id="username" placeholder="Digite seu nickname">

            <button type="submit">
                Gerar Pergunta
            </button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\random-quizz\resources\views/home.blade.php ENDPATH**/ ?>